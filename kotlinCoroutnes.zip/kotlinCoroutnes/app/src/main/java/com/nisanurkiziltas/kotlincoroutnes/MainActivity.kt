package com.nisanurkiziltas.kotlincoroutnes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

      /*  GlobalScope.launch {
            repeat(100000){
                launch {
                    println("android")
                }
            }

        } */

       /* println("run blocking start")
        runBlocking(){
            launch {
                delay(5000)
                println("run blocking")
            }
        }
        println("run blocking fnish")

*/

 /*println("coroutine scope start")
        CoroutineScope(Dispatchers.Default){
            delay(5000)
            println("corutien scope")
        }
        println("coroutine scope end") */


         runBlocking {
             launch(Dispatchers.Main) { println("main thread: ${Thread.currentThread().name}") }
             launch (Dispatchers.IO){ println("IO threat : ${Thread.currentThread().name}")  }
             launch(Dispatchers.Default) { println("default thread : ${Thread.currentThread().name}")  }
             launch (Dispatchers.Unconfined){ println("Uncofined thread : ${Thread.currentThread().name}") }

             }
         }



    }
