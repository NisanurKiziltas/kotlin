package com.nisanurkiziltas.kotlincoroutnes

import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking

fun main (){

    runBlocking {

    }

}
suspend fun dowloadName(): String {
    delay(2000)
    val username = "Nİsa : "
    println("username download")
    return username

}

suspend fun  dowloadAge(): Int{
    delay(4000)
    val userAge = 21
    println("user age dowlad")
    return  userAge



}
