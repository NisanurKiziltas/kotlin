package com.nisanurkiziltas.countdpwn

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.telephony.TelephonyCallback.ActiveDataSubscriptionIdListener
import com.nisanurkiziltas.countdpwn.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var tasarim : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        tasarim = ActivityMainBinding.inflate(layoutInflater)
        setContentView(tasarim.root)

        tasarim.buttonBasla.setOnClickListener{
            val sayici = object :CountDownTimer(30000,1000) {

                override fun onTick(p0:Long){
                    tasarim.Cikti.text = "kalan süre  ${p0 /1000} sn "

                }

                override fun onFinish() {
                    tasarim.Cikti.text = "bitti !!"
                }

            }


            sayici.start()

        }
    }
}
