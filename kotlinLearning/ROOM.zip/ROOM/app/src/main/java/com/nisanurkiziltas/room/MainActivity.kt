package com.nisanurkiziltas.room

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.coroutines.CoroutineContext

class MainActivity : AppCompatActivity() {
    private lateinit var vt:Veritabani
    private lateinit var kdao:KisilerDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vt= Veritabani.veritabaniErisim(this)!!
        kdao = vt.getKisilerDao()

        kisileriYükle()
        kisileriEkle()

    }
    fun kisileriYükle(){
        val job= CoroutineScope(Dispatchers.Main).launch {
            val gelenListe = kdao.tumKisiler()

            for (k in gelenListe){

                Log.e("kisi_id", k.kisi_id.toString())
                Log.e("kisi_ad",k.kisi_ad.toString())
                Log.e("kisi_yas",k.kisi_yas.toString())


            }
        }

    }



    fun kisileriEkle(){
        val job= CoroutineScope(Dispatchers.Main).launch {
            val yeniKisi= Kisiler(0,"ahmet",40)
            kdao.kisiEkle(yeniKisi)

            }
        }


    fun kisileriGüncelle(){
        val job= CoroutineScope(Dispatchers.Main).launch {
            val GüncelleKisi= Kisiler(0,"ahmet",40)
            kdao.kisiGüncelle(GüncelleKisi)

        }
    }



    }




