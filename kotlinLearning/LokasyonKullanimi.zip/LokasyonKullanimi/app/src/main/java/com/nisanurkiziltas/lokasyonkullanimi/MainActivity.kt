package com.nisanurkiziltas.lokasyonkullanimi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.nisanurkiziltas.lokasyonkullanimi.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var tasarim : ActivityMainBinding
    private var izinKontrol = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasarim = ActivityMainBinding.inflate(layoutInflater)
        setContentView(tasarim.root)

        tasarim.buttonKonumAl.setOnClickListener{

            izinKontrol = ContextCompat.checkSelfPermission(this,
                Manifest
                    .permission
                    .ACCESS_FINE_LOCATION)



        }
    }
}