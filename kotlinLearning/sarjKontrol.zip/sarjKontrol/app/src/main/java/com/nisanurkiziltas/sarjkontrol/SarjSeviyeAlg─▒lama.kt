package com.nisanurkiziltas.sarjkontrol

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class SarjSeviyeAlgılama: BroadcastReceiver() {
    override fun onReceive(context: Context?, intent: Intent?) {
        Toast.makeText(context,"şarjınız bitmek üzere :(",Toast.LENGTH_SHORT).show()


    }


}