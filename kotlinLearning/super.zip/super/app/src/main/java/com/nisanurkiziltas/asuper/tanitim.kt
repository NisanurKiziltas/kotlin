package com.nisanurkiziltas.asuper

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class tanitim : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tanitim)
    }
}