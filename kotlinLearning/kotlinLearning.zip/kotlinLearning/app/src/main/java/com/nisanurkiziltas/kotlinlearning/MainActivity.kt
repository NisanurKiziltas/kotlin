package com.nisanurkiziltas.kotlinlearning

import android.app.Activity
import androidx.appcompat.app.AppCompatActivity
import com.nisanurkiziltas.kotlinlearning.databinding.ActivityMainBinding
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    lateinit var binding:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //button
        //editTextNumber
        //textView
        binding.button.setOnClickListener{
            if(binding.editTextNumber.text.isNotEmpty()){
                var plakaKodu =binding.editTextNumber.text.toString().toInt()
                when(plakaKodu){
                    35 ->binding.textView.text="İzmir"
                    else -> {
                        binding.
                    }
                }
            }
            else{
                binding.editTextNumber.text="şehir plaka kodunu gir"

            }
        }

    }
}