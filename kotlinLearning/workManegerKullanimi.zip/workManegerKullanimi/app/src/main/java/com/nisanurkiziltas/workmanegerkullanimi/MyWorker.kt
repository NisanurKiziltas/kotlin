package com.nisanurkiziltas.workmanegerkullanimi

import android.content.Context
import android.content.ContextParams
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters

class MyWorker(appContext: Context, workerParams: WorkerParameters) :Worker(appContext,workerParams) {


    //arka planda işlemler yapmamızı sağlayan fonksiyon
    override fun doWork(): Result {
        val toplam = 10 +20
        Log.e("arkaplan işlem sonucu : ",toplam.toString())
        return Result.success()
    }
}