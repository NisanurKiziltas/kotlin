package com.nisanurkiziltas.animasyonislemleri

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.delay

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button: Button = findViewById(R.id.button)


        button.setOnClickListener {
            //Toast.makeText(applicationContext, "TEST", Toast.LENGTH_SHORT).show()
           // alphaAnimasyonu()
            //rotate()
            CokluAnimasyon()
        }
    }

    fun CokluAnimasyon(){

        val resim: ImageView = findViewById(R.id.resim)
        val a =ObjectAnimator.ofFloat(resim,"alpha",1.0f,0.0f)
        val sx =ObjectAnimator.ofFloat(resim,"scaleX",1.0f,2.0f)
        val sy = ObjectAnimator.ofFloat(resim,"scaleY",1.0f,3.0f)

        val coklu= AnimatorSet().apply{

            duration = 3000
            playTogether(sx,sy,a)
        }
        coklu.start()

    }

/*
    fun rotate(){
        val yazi : TextView = findViewById(R.id.yazi)
        val rotate = ObjectAnimator.ofFloat(yazi,"rotation",45.0f,90.0f).apply {
            duration = 3000

            val rotategeri = ObjectAnimator.ofFloat(yazi,"rotation",180.0f,0.0f).apply {
                startDelay = 1000
                duration = 3000

                val transX = ObjectAnimator.ofFloat(yazi, "translationX",0.0f,110.0f).apply {
                    startDelay = 2000
                    duration = 3000

                    val transY = ObjectAnimator.ofFloat(yazi, "translationY",0.0f,-110.0f).apply {
                        startDelay = 2000
                        duration = 3000

                    }
                    transY.start()

                }
                transX.start()
            }

            rotategeri.start()


        }
        rotate.start()

    }

    fun alphaAnimasyonu(){
        val resim : ImageView = findViewById(R.id.resim)
        //val a = ObjectAnimator.ofFloat(resim, "alpha",1.0f,0.0f).apply {
         //   duration = 3000
        //}
       // a.start()

        // kaybolma animasyonu

        val kaybol= ObjectAnimator.ofFloat(resim,"alpha",1.0f,0.0f).apply {
            duration= 3000

            val geri = ObjectAnimator.ofFloat(resim,"alpha",0.0f,1.0f).apply {
                startDelay = 1000
                duration= 3000

                val scalex = ObjectAnimator.ofFloat(resim,"scaleX", 1.0f,2.0f).apply {
                    startDelay = 1000
                    duration = 3000
                }
                scalex.start()

                val scaley = ObjectAnimator.ofFloat(resim,"scaleY",1.0f,2.0f).apply {
                    startDelay= 1000
                    duration = 3000
                }
                scaley.start()

               /* val scalexgeri = ObjectAnimator.ofFloat(resim,"scaleX",2.0f,1.0f).apply {
                    startDelay = 1000
                    duration = 3000
                }
                scalexgeri.start()

                val scaleygeri = ObjectAnimator.ofFloat(resim,"scaleY",2.0f,1.0f).apply {
                    startDelay = 1000
                    duration = 3000
                }
                scaleygeri.start()

                */
            }
            geri.start()


        }

        kaybol.start()


    }

 */

}
