package com.nisanurkiziltas.workmanager

import android.annotation.SuppressLint
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class RefleshDataBase(val context: Context, workerParams: WorkerParameters) : Worker(context,
    workerParams
) {
    override fun doWork(): Result {
        val getData = inputData

        val myNumber = getData.getInt("intKey",0)

        RefleshDataBase(myNumber)
        return Result.success()
    }

    @SuppressLint("NotConstructor")
    private fun RefleshDataBase(myNumber: Int){
        val sharedPreferences = context.getSharedPreferences("com.nisanurkiziltas.workmanager", Context.MODE_PRIVATE)
        var mySavedNumber=  sharedPreferences.getInt("myNumber",0)
        mySavedNumber = mySavedNumber+ myNumber
        println(mySavedNumber)
        sharedPreferences.edit().putInt("myNumber",mySavedNumber)


    }


}