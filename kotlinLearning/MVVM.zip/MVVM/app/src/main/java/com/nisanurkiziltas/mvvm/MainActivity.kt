package com.nisanurkiziltas.mvvm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.nisanurkiziltas.mvvm.databinding.ActivityMainBinding

class MainActivity: AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

       // binding = ActivityMainBinding.inflate(layoutInflater) // View Binding ile bağlantı sağlandı

        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)

        // Eğer textViewSonuc adında bir view kullanıyorsanız, bu view'e View Binding ile erişmek için aşağıdaki gibi kullanabilirsiniz:
        binding.hesaplamaSonucu = "0"
        binding.mainActivityNesnesi = this

        //binding.buttontoplama.setOnClickListener {
            //val alinanSayi1 = binding.editTextSayi1.text.toString()
            //val alinanSayi2 =binding.editTextSayi2.text.toString()

            //val sayi1 = alinanSayi1.toInt()
            //val sayi2 = alinanSayi2.toInt()

            //val  toplam= sayi1 +sayi2

            //binding.textViewSonuc.text = toplam.toString()

        //}


       // binding.buttonCarpma.setOnClickListener {
            //val alinanSayi1 = binding.editTextSayi1.text.toString()
            //val alinanSayi2 =binding.editTextSayi2.text.toString()

            //val sayi1 = alinanSayi1.toInt()
            //val sayi2 = alinanSayi2.toInt()

            //val  carp= sayi1 *sayi2

            //binding.textViewSonuc.text = carp.toString()


       // }
    }

    fun buttonToplamaTikla(alinanSayi1:String,alinanSayi2:String){

        val sayi1 = alinanSayi1.toInt()
        val sayi2 = alinanSayi2.toInt()

        val  toplam= sayi1 +sayi2

        binding.textViewSonuc.text = toplam.toString()

    }

    fun buttonCarpmaTikla(alinanSayi1:String,alinanSayi2:String){

        val sayi1 = alinanSayi1.toInt()
        val sayi2 = alinanSayi2.toInt()

        val  carp= sayi1 *sayi2

        binding.textViewSonuc.text = carp.toString()

    }
}