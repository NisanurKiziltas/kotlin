package com.nisanurkiziltas.superkahraman

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class tanıtım : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}