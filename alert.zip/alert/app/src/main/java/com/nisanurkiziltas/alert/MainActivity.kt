package com.nisanurkiziltas.alert

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //mesajlar üç çeşit 1) toast 2)alert dialog 3)snackbar

        //contex : android işlemtim sisteminde nerde ne olduğunu göstermek için bir yapı.bir ekrandan diğerine gitmek gibi kullanıcı ile iletişime geçmek için kullanılıur.
        // activity contex : this ile yapılır
        //application contex: applicationcontex ile yapılır.

        //Toast.makeText(this,"naber oğlum", Toast.LENGTH_LONG).show()
       // Toast.makeText(applicationContext,"applicationCongtext deneme",Toast.LENGTH_LONG).show()

        //lambda : anonim


    }

    fun tıkla(view : View){
        //alert dialog
        val alert = AlertDialog.Builder(this@MainActivity)
        alert.setTitle("nisanur ve ahmet")
        alert.setMessage(/* message = */ "evleniyorrrr")
        alert.show()
    }
}