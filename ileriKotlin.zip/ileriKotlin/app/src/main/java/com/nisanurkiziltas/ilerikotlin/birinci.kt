package com.nisanurkiziltas.ilerikotlin

class birinci : Thread() {

    override fun run() {
       for( i in 100..199)
           print("birinci thread : $i")
           Thread.sleep(100)
    }
}
