package com.nisanurkiziltas.ilerikotlin

fun run(){

    val birinciThread =birinci()
    birinciThread.start()

    val ikinciThread = Thread(ikinci())
    ikinciThread.start()

    for(i in 900..999){
        println("Main thread : $i")
        Thread.sleep(100)
    }

}