package com.nisanurkiziltas.ilerikotlin

class ikinci : Runnable {
    override fun run() {
        for (i in 200..299){
            println("ikinci thread : $i")
            Thread.sleep(100)
        }
    }
}