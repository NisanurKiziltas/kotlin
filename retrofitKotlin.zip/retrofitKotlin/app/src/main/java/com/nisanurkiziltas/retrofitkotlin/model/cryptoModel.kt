package com.nisanurkiziltas.retrofitkotlin.model

import com.google.gson.annotations.SerializedName

data class cryptoModel(
    //@SerializedName("currency")
    val currency:String,
    //@SerializedName("price")
    val price: String
    )