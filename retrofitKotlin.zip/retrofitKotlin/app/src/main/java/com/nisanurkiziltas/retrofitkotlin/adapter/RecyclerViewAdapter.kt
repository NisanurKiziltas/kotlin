package com.nisanurkiziltas.retrofitkotlin.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.nisanurkiziltas.retrofitkotlin.R
import com.nisanurkiziltas.retrofitkotlin.model.cryptoModel
import kotlinx.android.synthetic.main.activity_main.*

class RecyclerViewAdapter(private val cryptoList :ArrayList<cryptoModel>) : RecyclerView.Adapter<RecyclerViewAdapter.RowHolder>() {

   private val calor :ArrayList<String> = arrayOf("#85595f","#d6bad4","#ebc5d9","#6897bb","#ffe7bc","#dddddd","#b2e39c","#9cd6e3","#aa9ce3","#6897bb")
    class RowHolder (view: View): RecyclerView.ViewHolder(view) {
        fun bind(cryptoModel: cryptoModel){
            itemView.setBackgroundColor()
            itemView.text_name.text = cryptoModel.currency
            itemView.text_price.text =cryptoModel.price

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
        val view =LayoutInflater.from(parent.context).inflate(R.layout.row_layout,parent,false)
        return RowHolder(view)
    }

    override fun getItemCount(): Int {
       return cryptoList.count()
    }

    override fun onBindViewHolder(holder: RowHolder, position: Int) {



    }
}