package com.nisanurkiziltas.retrofitkotlin.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.nisanurkiziltas.retrofitkotlin.R
import com.nisanurkiziltas.retrofitkotlin.model.cryptoModel
import com.nisanurkiziltas.retrofitkotlin.service.cryptoApı
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    private val Base_URL = "https://raw.githubusercontent.com/"
    private var CryptoModels: ArrayList<cryptoModel>? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //https://raw.githubusercontent.com/
        // atilsamancioglu/K21-JSONDataSet/master/crypto.json

        loadData()

    }

    private fun loadData (){

        val retrofit = Retrofit.Builder()
            .baseUrl(Base_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val service = retrofit.create(cryptoApı::class.java)
        val call = service.getData()

        call.enqueue(object: Callback<List<cryptoModel>>{

            override fun onFailure(call: Call<List<cryptoModel>>, t: Throwable) {
                t.printStackTrace()
            }

            override fun onResponse(call: Call<List<cryptoModel>>, response: Response<List<cryptoModel>>
            ) {
               if(response.isSuccessful){
                   response.body()?.let {
                       CryptoModels = ArrayList(it)
                   }
               }
            }

        })



    }

}