package com.nisanurkiziltas.retrofitkotlin.service

import com.nisanurkiziltas.retrofitkotlin.model.cryptoModel
import retrofit2.http.GET

interface cryptoApı {
    //https://raw.githubusercontent.com/
    // atilsamancioglu/K21-JSONDataSet/master/crypto.json
    @GET("atilsamancioglu/K21-JSONDataSet/master/crypto.json")

    fun getData(): retrofit2.Call<List<cryptoModel>>
}