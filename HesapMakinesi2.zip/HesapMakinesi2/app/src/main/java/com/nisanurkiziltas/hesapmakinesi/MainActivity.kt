package com.nisanurkiziltas.hesapmakinesi

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText



class MainActivity : AppCompatActivity() {
    private lateinit var btn0: Button
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btn3: Button
    private lateinit var btn4: Button
    private lateinit var btn5: Button
    private lateinit var btn6: Button
    private lateinit var btn7: Button
    private lateinit var btn8: Button
    private lateinit var btn9: Button
    private lateinit var  btnArtiEksi: Button
    private lateinit var btnAC: Button
    private lateinit var btnyuzde: Button
    private lateinit var btnbol: Button
    private lateinit var btncarp: Button
    private lateinit var btncikar: Button
    private lateinit var btntopla: Button
    private lateinit var btnesit: Button
    private lateinit var btnnokta: Button




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn0 = findViewById(R.id.btn0)
        btn1 = findViewById(R.id.btn1)
        btn2 = findViewById(R.id.btn2)
        btn3 = findViewById(R.id.btn3)
        btn4 = findViewById(R.id.btn4)
        btn5 = findViewById(R.id.btn5)
        btn6 = findViewById(R.id.btn6)
        btn7 = findViewById(R.id.btn7)
        btn8 = findViewById(R.id.btn8)
        btn9 = findViewById(R.id.btn9)
        btnArtiEksi = findViewById(R.id. btnArtiEksi)
        btnAC = findViewById(R.id.btnAC)
        btnyuzde = findViewById(R.id.btnyuzde)
        btnbol = findViewById(R.id.btnbol)
        btncarp = findViewById(R.id.btncarp)
        btncikar = findViewById(R.id.btncikar)
        btntopla = findViewById(R.id.btntopla)
        btnesit = findViewById(R.id.btnesit)
        btnnokta = findViewById(R.id.btnnokta)


    }
    @SuppressLint("WrongViewCast")
    fun btnSayiTik(view: View){

        if(yeniOperator){
            var sayiG = findViewById<EditText>(R.id.sayiG)
            sayiG.setText("")
        }
        yeniOperator = false

        var btnSec = view as Button
        var sayiG = findViewById<EditText>(R.id.sayiG)
        var btnTikDeger: String = sayiG.text.toString()

        when(btnSec.id) {
            btn0.id->{
                btnTikDeger+="0"
            }

            btn1.id->{
                btnTikDeger+="1"
            }

            btn2.id->{
                btnTikDeger+="2"
            }

            btn3.id->{
                btnTikDeger+="3"
            }

            btn4.id->{
                btnTikDeger+="4"
            }

            btn5.id->{
                btnTikDeger+="5"
            }

            btn6.id->{
                btnTikDeger+="6"
            }

            btn7.id->{
                btnTikDeger+="7"
            }

            btn8.id->{
                btnTikDeger+="8"
            }
            btn9.id->{
                btnTikDeger+="9"
            }

            btnArtiEksi.id->{
               btnTikDeger = "-"+btnTikDeger
            }

        }
        sayiG.setText(btnTikDeger)
    }

    var operator = "*"
    var eskiSayi = ""
    var yeniOperator = true


    fun btnOpTik (view: View){
        var btnSec = view as Button

        when(btnSec.id){

            btnbol.id->{
                operator = "/"
            }

            btncarp.id->{
                operator = "X"
            }

            btntopla.id -> {
                operator = " +"
            }

            btncikar.id -> {
                operator = "-"
            }



        }
        var sayiG = findViewById<EditText>(R.id.sayiG)
        eskiSayi = sayiG.text.toString()
        yeniOperator = true
    }

    fun btnEsittirTik(view: View){
        var sayiG = findViewById<EditText>(R.id.sayiG)
        var yeniSayi = sayiG.text.toString()
        var sonucSayisi : Double? = null

        when(operator){

            "/"->{
                sonucSayisi = eskiSayi.toDouble() / yeniSayi.toDouble()

            }

            "X"->{
                sonucSayisi = eskiSayi.toDouble() * yeniSayi.toDouble()

            }
            "+"->{
                sonucSayisi = eskiSayi.toDouble() + yeniSayi.toDouble()

            }
            "-"->{
                sonucSayisi = eskiSayi.toDouble() - yeniSayi.toDouble()

            }

        }

        sayiG.setText(sonucSayisi.toString())
        yeniOperator = true



    }

    fun btnSilTik(view: View) {
        var sayiG = findViewById<EditText>(R.id.sayiG)
        sayiG.setText("0")
        yeniOperator = true


    }

    fun btnYuzdeTik(view: View) {
        var sayiG = findViewById<EditText>(R.id.sayiG)
        var sayi: Double = sayiG.text.toString().toDouble()/100
        sayiG.setText(sayi.toString())
        yeniOperator = true


    }


}