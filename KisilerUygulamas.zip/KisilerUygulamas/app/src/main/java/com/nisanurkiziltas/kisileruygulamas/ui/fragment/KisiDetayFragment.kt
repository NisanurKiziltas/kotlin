package com.nisanurkiziltas.kisileruygulamas.ui.fragment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.navArgs
import com.nisanurkiziltas.kisileruygulamas.R
import com.nisanurkiziltas.kisileruygulamas.databinding.FragmentKisiDetayBinding

class KisiDetayFragment : Fragment() {

    private lateinit var tasarim :FragmentKisiDetayBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        tasarim =  FragmentKisiDetayBinding.inflate(inflater, container, false)
        tasarim.toolbarKisiDetay.title = "Kişi Detay"

        val bundle : KisiDetayFragmentArgs by navArgs()
        val gelenKisi = bundle.kisi

        tasarim.editTextLisiAd.setText(gelenKisi.kisi_ad)
        tasarim.editTextKisiTel.setText(gelenKisi.kisi_tel)


        tasarim.buttonGNcelle.setOnClickListener(){
            val kisi_ad = tasarim.editTextLisiAd.text.toString()
            val kisi_tel = tasarim.editTextKisiTel.text.toString()

            güncelle(gelenKisi.kisi_id, kisi_ad,kisi_tel)

        }

        return tasarim.root
    }

    fun güncelle (kisi_id : Int,kisi_ad:String,kisi_tel : String){
        Log.e("kişi güncelle ","$kisi_id - $kisi_ad - $kisi_tel")

    }

}