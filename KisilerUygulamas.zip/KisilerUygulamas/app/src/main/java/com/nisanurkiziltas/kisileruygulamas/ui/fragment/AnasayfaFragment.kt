package com.nisanurkiziltas.kisileruygulamas.ui.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.MenuProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.Lifecycle.State.*
import androidx.navigation.Navigation
import com.nisanurkiziltas.kisileruygulamas.R
import com.nisanurkiziltas.kisileruygulamas.databinding.FragmentAnasayfaBinding

class AnasayfaFragment : Fragment() {

    private lateinit var tasarim : FragmentAnasayfaBinding

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        tasarim = FragmentAnasayfaBinding.inflate(inflater, container, false)

        tasarim.toolbarAnasayfa.title = "Kişiler"

        (activity as AppCompatActivity).setSupportActionBar(tasarim.toolbarAnasayfa)

        tasarim.fab.setOnClickListener(){
            Navigation.findNavController(it).navigate(R.id.KisiKayitGecis)
        }


        requireActivity().addMenuProvider(object :MenuProvider{

            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {

                menuInflater.inflate(R.menu.toolbar_menu,menu)

            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {

                return false
            }

        },viewLifecycleOwner,Lifecycle.State.RESUMED)


        return tasarim.root
    }



}