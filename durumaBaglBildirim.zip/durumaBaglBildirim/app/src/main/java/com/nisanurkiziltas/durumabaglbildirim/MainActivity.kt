package com.nisanurkiziltas.durumabaglbildirim

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import com.nisanurkiziltas.durumabaglbildirim.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var  tasarim : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tasarim = ActivityMainBinding.inflate(layoutInflater)
        setContentView(tasarim.root)

        tasarim.buttonBildir.setOnClickListener{
            val builder: NotificationCompat.Builder

            val BildirimYöneticisi = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val intent =  Intent(this,MainActivity::class.java)

            val gidilecekIntent = PendingIntent.getActivity(this,1,intent, PendingIntent.FLAG_UPDATE_CURRENT)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){

                val kanalId = "kanalId"
                val kanalAd = " kanalAd"
                val kanalTanıtım ="kanalTanıtım"
                val kanalOnceliği = NotificationManager.IMPORTANCE_HIGH


                var kanal : NotificationChannel? = BildirimYöneticisi.getNotificationChannel(kanalId)

                if(kanal ==null){
                    kanal = NotificationChannel(kanalId,kanalAd,kanalOnceliği)
                    kanal.description = kanalTanıtım
                    BildirimYöneticisi.createNotificationChannel(kanal)
                }

                builder = NotificationCompat.Builder(this,kanalId)

                builder.setContentTitle("BAŞLIK")
                    .setContentText("içerik")
                    .setSmallIcon("R.drawable.resim")
                    .setContentIntent(gidilecekIntent)
                    .setAutoCancel(true)

            }

            else{

                builder = NotificationCompat.Builder(this)

                builder.setContentTitle("BAŞLIK")
                    .setContentText("içerik")
                    .setSmallIcon("R.drawable.resim")
                    .setContentIntent(gidilecekIntent)
                    .setAutoCancel(true)
                    .priority = Notification.PRIORITY_HIGH




            }

            BildirimYöneticisi.notify(1,builder.build())

        }


    }
}