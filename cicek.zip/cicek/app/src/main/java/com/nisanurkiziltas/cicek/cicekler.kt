package com.nisanurkiziltas.cicek

class cicekler {

    var constAdi : String? = null
    var constAciklama : String? = null
    var constResim : Int? = null

    constructor(constAdi : String,constAciklama : String,constResim : Int){

        this.constAdi = constAdi
        this.constAciklama = constAciklama
        this.constResim = constResim



    }

}