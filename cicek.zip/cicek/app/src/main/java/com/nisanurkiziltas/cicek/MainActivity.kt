package com.nisanurkiziltas.cicek

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter

class MainActivity : AppCompatActivity() {

    var constList =ArrayList<cicekler>()
    var adepter : ciceklerAdapter? =null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        constList.add(cicekler("Gül","açıklama",R.drawable.gul))
        constList.add(cicekler("Lale","açıklama",R.drawable.lale))
        constList.add(cicekler("Kasımpatı","açıklama",R.drawable.kasimpati))
        constList.add(cicekler("Menekşe","açıklama",R.drawable.menekse))
        constList.add(cicekler("Nergis","açıklama",R.drawable.nergis))
        constList.add(cicekler("Orkide","açıklama",R.drawable.orkide))
        constList.add(cicekler("Ortanca","açıklama",R.drawable.ortanca))
        constList.add(cicekler("Papatya","açıklama",R.drawable.papatya))

    }

    class ciceklerAdapter: BaseAdapter() {
        var constList = ArrayList<cicekler>()
        var context:Context? =null
        constructor(context:Context,constList : ArrayList<cicekler>):super(){
            this.constList=constList
            this.context = context
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            var posCicekler :cicekler =constList[position]
            var inflator:LayoutInflater=context.getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
            var cicekKarti = inflator.inflate(R.layout.cicek_karti,null)
            cicekKarti.kartAdi.text = Pos


        }

        override fun getItem(position: Int): Any {
            return  constList[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return constList.size
        }







    }
}