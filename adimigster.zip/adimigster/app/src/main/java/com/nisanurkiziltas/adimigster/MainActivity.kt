package com.nisanurkiziltas.adimigster

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    // XML dosyasındaki öğeleri tanımlamak için değişkenleri oluşturun
    private lateinit var button: Button
    private lateinit var adSoyad: EditText
    private lateinit var goster: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Tanımlanan değişkenlere XML dosyasındaki öğeleri atayın
        button = findViewById(R.id.button)
        adSoyad = findViewById(R.id.adSoyad)
        goster = findViewById(R.id.goster)

        // Olay dinleyicilerini ayarlayın
        button.setOnClickListener {
            goster.text = adSoyad.text.toString()
            adSoyad.text.clear()
        }
    }
}
