package com.nisanurkiziltas.dagger

import android.util.Log

class kargo {
    var adres =ADRESS("osmangazi/Bursa")

    fun gonder(){
        Log.e("sonuc","kargo ${adres.adresBilgisi} adresine gönderildi")

    }
}