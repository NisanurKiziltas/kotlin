package com.nisanurkiziltas.dagger

import  dagger.Module
@Module



class AppModule {
}