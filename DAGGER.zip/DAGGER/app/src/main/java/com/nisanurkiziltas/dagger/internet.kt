package com.nisanurkiziltas.dagger

import android.util.Log

class internet {

    var adres =ADRESS("osmangazi/Bursa")

    fun basvuruYap(){
        Log.e("sonuc","İnternet başvurusu  ${adres.adresBilgisi} adresinden geldi")

    }

}