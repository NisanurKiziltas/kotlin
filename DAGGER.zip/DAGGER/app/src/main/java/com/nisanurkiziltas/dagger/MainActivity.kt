package com.nisanurkiziltas.dagger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    private lateinit var kargo: kargo
    private lateinit var internet: internet
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        kargo = kargo()
        kargo.gonder()

        internet = internet()
        internet.basvuruYap()
    }
}