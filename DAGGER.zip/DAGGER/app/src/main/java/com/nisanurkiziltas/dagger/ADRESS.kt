package com.nisanurkiziltas.dagger

class ADRESS(var adresBilgisi:String) {
}