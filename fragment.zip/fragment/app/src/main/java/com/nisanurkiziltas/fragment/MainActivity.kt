package com.nisanurkiziltas.fragment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun ilkFragment (view: View){
        val fragmentManager = supportFragmentManager
        var fragmentTransaction = fragmentManager.beginTransaction()

        val ilkFragment = BlankFragment()
        //fragmentTransaction.add(R.id.frameLayout,ilkFragment).commit()
        fragmentTransaction.replace(R.id.frameLayout,ilkFragment).commit()



    }

    fun ikinciFragment (view: View){

        val fragmentManager = supportFragmentManager
        var fragmentTransaction = fragmentManager.beginTransaction()

        val ikinciFragment = BlankFragment2()
       // fragmentTransaction.add(R.id.frameLayout,ikinciFragment).commit()
        fragmentTransaction.replace(R.id.frameLayout,ikinciFragment).commit()

    }
}